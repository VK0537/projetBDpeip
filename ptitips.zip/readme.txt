Bonjour !
Voici le groupe ayant travaillé sur le projet Ptitips : 
Rania Abdelkhaleq, Bastien Jourdan-Ferry, Lucie Bouvet, Lucas Bonneaud et Viktor Brothier. 
Il manque encore quelques pages donc vous risquez de tomber sur des 404
Voici les fonctionnalitées que nous n'avons pas encore implémentées : 
- newsletter
- barre de recherche et recherche par catégorie
- clic sur les tags d'articles qui ne sont pas les catégories (prix, difficultées, ...)
- boutton news
- page profil
- sous titre des cartes

Le site est disponible à l'adresse http://ptitips.ga sans l'api google maps

Pour faire fonctionner correctement notre site sur XAMPP, vous avez besoin de 3 choses : 
- modifier httpd.conf
- modifier php.ini
- les clés d'api et de base de données

HTTPD.CONF : 
Cherchez la ligne DocumentRoot et celle juste en dessous appelée <Directory et remplacez 
le contenu par le répertoire où vous avez trouvé ce readme. 
Puis, toujours dans cette catégorie, allez à la ligne intitulée AllowOverride et changez 
le contenu en All , ce qui permettra au fichier .htaccess de changer la configuration. 

PHP.INI : 
Rendez-vous dans la catégorie [mail functions] puis : 
SMTP=smtp.gmail.com
smtp_port=587
sendmail_from = ptitipsfr@gmail.com

CLE API ET DB : 
Les clés se trouvent dans un fichier keys.json, nous sommes concients que nous ne pouvons 
pas les stocker sur le serveur web sans prendre des mesures de sécurité.
Nous comptons sur votre discretion concernant la clé d'api. Elles sont utilisées 
automatiquement.

Si vous avez aimé le site, inscrivez vous et mettez un commentaire dans le chat!!!

PS:j'ai fait à la main l'erreur 404 ( https://codepen.io/vk0537/pen/vYxNXgE ) 
dites moi ce que vous en pensez...
Nous avons tout fait à la main avec de la doc mais sans aucun copier-coller (à part le 
script pour customiser la balise select qui est une adaptation de celle de W3school...)